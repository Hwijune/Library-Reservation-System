

import java.sql.*;

public class valuepropagation {
   
    private static final String OJDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static Connection conn = null;
    private static PreparedStatement pstmt = null;
    private static ResultSet rs = null;

   public static void main(String[] args) {
        String username = "r_216_06";
        String password = "100006";
        
        String jdbcUrl = "jdbc:mysql://localhost:3306/lrs";
        String jdbcId = "root";
        String jdbcPw = "rootpass";

        try {
            
            Class.forName(OJDBC_DRIVER);
          conn = DriverManager.getConnection("jdbc:oracle:thin:@210.119.146.56:1521:orcl", username, password);
          String query = "select stu_name, stu_addr from student_033";
          pstmt = conn.prepareStatement(query);
          rs = pstmt.executeQuery();
            
            while(rs.next()) {
               System.out.println(rs.getString(1) + ", " + rs.getString(2));
            }
            conn.close();
            pstmt.close();
            rs.close();
           
          
            
        } catch(Exception e) {
           e.printStackTrace();
        }
        

   }

}