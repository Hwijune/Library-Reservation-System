package user;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import util.DatabaseUtil;

public class UserLoginController implements Initializable {

	@FXML private Button loginButton;
	@FXML private Button joinButton;
	@FXML private TextField userID;
	@FXML private PasswordField userPassword;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		loginButton.setOnAction(event->{
			try
			{
				loginButtonAction(event);
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		joinButton.setOnAction(event->joinButtonAction(event));
	}
	
	public void loginButtonAction(ActionEvent event) throws IOException {
		String userID = this.userID.getText();
		String userPassword = this.userPassword.getText();
		if(userID == null || userPassword == null ||
		   userID.equals("") || userPassword.equals("")) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� �޽���");
			alert.setHeaderText("������ �߻��߽��ϴ�.");
			alert.setContentText("���̵� Ȥ�� ��й�ȣ�� �� ������ �� �����ϴ�.");
			alert.showAndWait();
			return;
		}
		UserDAO userDAO = new UserDAO();
		int result = userDAO.login(userID, userPassword);
		
		if(userID.equals("admin"))
		{
			String SQL2 = "SELECT adminPassword FROM admin WHERE adminId = ?";
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = DatabaseUtil.getConnection();
				
				pstmt = conn.prepareStatement(SQL2);
				pstmt.setString(1, userID);
				rs = pstmt.executeQuery();
				rs.next();
				if(rs.getString(1).equals("admin"))
				{
					Parent parent = FXMLLoader.load(getClass().getResource("../user/insertbook.fxml"));
					Scene scene = new Scene(parent);
					Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
					stage.setScene(scene);
					stage.show();
					System.out.println("������");
				}
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if(conn != null) try {conn.close();} catch (Exception e) {e.printStackTrace();}
				if(pstmt != null) try {pstmt.close();} catch (Exception e) {e.printStackTrace();}
			}
		}
		else if(result == 1) {
			try {
				Main.userID = userID;
				Parent parent = FXMLLoader.load(getClass().getResource("../main/Main.fxml"));
				Scene scene = new Scene(parent);
				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
				stage.setScene(scene);
				stage.show();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return;
		} else if (result == 0) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� �޽���");
			alert.setHeaderText("������ �߻��߽��ϴ�.");
			alert.setContentText("��й�ȣ�� Ʋ���ϴ�.");
			alert.showAndWait();
			return;
		} else if (result == -1) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� �޽���");
			alert.setHeaderText("������ �߻��߽��ϴ�.");
			alert.setContentText("�������� �ʴ� ���̵��Դϴ�.");
			alert.showAndWait();
			return;
		} else if (result == -2) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� �޽���");
			alert.setHeaderText("������ �߻��߽��ϴ�.");
			alert.setContentText("�����ͺ��̽� ������ �߻��߽��ϴ�.");
			alert.showAndWait();
			return;
		}
	}
	
	public void joinButtonAction(ActionEvent event) {
		try {
			Parent parent = FXMLLoader.load(getClass().getResource("UserJoin.fxml"));
			Scene scene = new Scene(parent);
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			stage.setScene(scene);
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
}
